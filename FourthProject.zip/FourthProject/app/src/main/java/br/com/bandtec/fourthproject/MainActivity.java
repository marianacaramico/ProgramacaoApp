package br.com.bandtec.fourthproject;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculoimc(View v){
        EditText txtpeso = findViewById(R.id.peso);
        double peso = Double.parseDouble(txtpeso.getText().toString());

        EditText txtaltura = findViewById(R.id.altura);
        double altura = Double.parseDouble(txtaltura.getText().toString());

        TextView textoexibido = findViewById(R.id.text);

        String text = "";
        int color;

        double imc = peso/Math.pow(altura,2);
        if(imc < 17){
            text = "Muito abaixo do peso";
            color = Color.parseColor("#ff00ff");
        } else if (imc >= 17 && imc <= 18.49){
            text = "Abaixo do peso";
            color = Color.CYAN;
        } else if (imc >= 18.5 && imc <= 24.99){
            text = "Peso normal";
            color = Color.BLUE;
        } else if (imc >= 25 && imc <= 29.99){
            text = "Acima do peso";
            color = Color.GREEN;
        } else if (imc >= 30 && imc <= 34.99){
            text = "Obesidade I";
            color = Color.YELLOW;
        } else if (imc >= 35 && imc <= 39.99){
            text = "Obesidade II (severa)";
            color = Color.parseColor("#ffff00");
        } else {
            text = "Obesidade III (mórbida)";
            color = Color.RED;
        }
        textoexibido.setText(text);
        textoexibido.setTextColor(color);
    }

}
