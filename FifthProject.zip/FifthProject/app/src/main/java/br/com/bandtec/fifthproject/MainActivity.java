package br.com.bandtec.fifthproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private EditText editn1;
    private EditText editn2;
    private TextView resultado;
    private TextView count;
    private Integer c = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editn1 = findViewById(R.id.n1);
        editn2 = findViewById(R.id.n2);
        resultado = findViewById(R.id.resultado);
        count = findViewById(R.id.count);
    }

    public void calcularSoma(View view) {
        double n1 = Double.valueOf(editn1.getText().toString());
        double n2 = Double.valueOf(editn2.getText().toString());
        double soma = n1 + n2;
        resultado.setText(""+soma);
        aumentarC();
    }

    public void calcularSubtracao(View view) {
        double n1 = Double.valueOf(editn1.getText().toString());
        double n2 = Double.valueOf(editn2.getText().toString());
        double subtracao = n1 - n2;
        resultado.setText(""+subtracao);
        aumentarC();
    }

    public void calcularMultiplicacao(View view) {
        double n1 = Double.valueOf(editn1.getText().toString());
        double n2 = Double.valueOf(editn2.getText().toString());
        double multiplicacao = n1 * n2;
        resultado.setText(""+multiplicacao);
        aumentarC();
    }

    public void calcularDivisao(View view) {
        double n1 = Double.valueOf(editn1.getText().toString());
        double n2 = Double.valueOf(editn2.getText().toString());
        double divisao = n1 / n2;
        resultado.setText(""+divisao);
        aumentarC();
    }

    public void aumentarC() {
        c++;
        count.setText(c+"ª operação");
    }

}
