/*
1. Costuma-se enumerar a média de gols de atacantes num campeonato. O Gabriel Jesus, por exemplo, homenageou o Palmeiras com 1 gol para cada mundial na última copa.

Crie um app android que tenha as seguintes entradas:
 O nome de um jogador;
 O número de jogos que disputou (só aceite números);
 O número de gols que marcou (só aceite números);
 Um botão com o texto "Calcular média"

Ao clicar no botão, o app deve exibir a mensagem:
"O jogador NOME teve uma média de X gols por partida"
(Um Toast)

 */



package br.com.bandtec.thirdproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /*public void exibirMensagem(View v) {
        //Exibindo uma mensagem
        //Toast.makeText(this, "Bla", Toast.LENGTH_SHORT).show();

        //Recuperando o elemento de id editnome
        EditText editNome = findViewById(R.id.editnome);
        //Recuperando o texto do elemento acima
        String nomeDigitado = editNome.getText().toString();
        Toast.makeText(this, "Você digitou "+nomeDigitado, Toast.LENGTH_SHORT).show();
    }*/

    public void calculaExibeMedia(View v) {
        EditText nome = findViewById(R.id.nome);
        String nomedigitado = nome.getText().toString();

        EditText jogos = findViewById(R.id.jogos);
        int quantidadejogos = Integer.parseInt(jogos.getText().toString());

        EditText gols = findViewById(R.id.gols);
        int quantidadegols = Integer.parseInt(jogos.getText().toString());

        int golspartida = quantidadegols/quantidadejogos;

        Toast.makeText(this, "O jogador "+nomedigitado+" teve uma média de "+golspartida+" gols por partida", Toast.LENGTH_SHORT).show();
    }

}
