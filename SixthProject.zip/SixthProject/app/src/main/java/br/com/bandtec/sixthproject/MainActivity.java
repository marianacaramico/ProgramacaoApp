package br.com.bandtec.sixthproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText txtSaldo;
    private EditText txtValor;
    private TextView saldoinsuficiente;
    private TextView informesaldo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSaldo = findViewById(R.id.saldo);
        txtValor = findViewById(R.id.valor);
        saldoinsuficiente = findViewById(R.id.saldoinsuficiente);
        informesaldo = findViewById(R.id.informesaldo);
    }

    private double saldo(){
        return Double.valueOf(txtSaldo.getText().toString());
    }

    private double valor(){
        return Double.valueOf(txtValor.getText().toString());
    }

    private void informeSaldo(){
        double saldo = saldo();
        if(saldo==0) informesaldo.setText("Informe o saldo");
    }

    private void saldoInsuficiente(){
        double saldo = saldo();
        double valor = valor();
        if(valor > saldo) saldoinsuficiente.setText("Saldo insuficiente para o valor solicitado");
    }

    public void somar1(View view) {
        double valor = valor();
        txtValor.setText(""+(valor+1));
        saldoInsuficiente();
        informeSaldo();
    }

    public void somar10(View view) {
        double valor = valor();
        txtValor.setText(""+(valor+10));
        saldoInsuficiente();
        informeSaldo();
    }

    public void somar50(View view) {
        double valor = valor();
        txtValor.setText(""+(valor+50));
        saldoInsuficiente();
        informeSaldo();
    }

    public void somar100(View view) {
        double valor = valor();
        txtValor.setText(""+(valor+100));
        saldoInsuficiente();
        informeSaldo();
    }
}
